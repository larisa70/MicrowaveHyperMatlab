clear 
close all


% first run the program ImageWraper_TimeSeries.m
% Obs! don't work since out of memory

%% Read the necessary data: the following rows are commented
% since they don't work  because of out of memory in Matlab

%LSKernel = load('LSKernel.mat');  
%FieldNameLSK = fieldnames(LSKernel);
%LSKernel = getfield(LSKernel,FieldNameLSK{1});

% this is a huge array  - I get error to read it and
% print out, need more memory
%disp("before gather(LSKernel)  ")
%newLSKernel = gather(LSKernel);

%disp("after gather(LSKernel)  ")


KernelT = load('KernelT.mat');  
FieldNameK = fieldnames(KernelT);
KernelT = getfield(KernelT,FieldNameK{1});

% the file drhs.mat is obtained after running ImageWraper*.m
% size(drhs) = 256
drhs = load('drhs.mat');  
FieldNamed = fieldnames(drhs);
drhs = getfield(drhs,FieldNamed{1});


% here is diag(Sigma), size(Sigma)= 256
Sigma = load('Sigma.mat');  
FieldNameSigma = fieldnames(Sigma);
Sigma = getfield(Sigma,FieldNameSigma{1});

% Kernel array is of the size 256 X 43680    
% Transposed Kernel has size  43680 X 256
disp("before gather(Kernel)'  ")
newKernel = gather(KernelT);

disp("after gather(Kernel)'  ")

nx= size(newKernel,1); %  n_x
ny =  size(newKernel,2); %  n_y



xmin=0.0;
ymin = 0.0;
sch = 0;

% to save data columnwise

disp("  before saving data columnwise")

for j=1:ny
  for i=1:nx
   
     sch = sch  + 1;
      % for Matlab visualization
     
     KernelMatlab(i,j) = newKernel(i+nx*(j-1));
    
 %  to use in FEM computations 
 
     KernelFEM(sch) = newKernel(i+nx*(j-1));
    
     %******************************************************
 
     
  end
end

sch = 0;
% to save data rowwise
%disp("  before saving data rowwise")

%  for i=1:nx
%    for j=1:ny
        
%   sch = sch +1;
      % for Matlab visualization
     
%     KernelMatlabrow(i,j) = newKernel(j+ny*(i-1));
    
     %  to use in FEM computations 
 
%     KernelrowFEM(sch) = newKernel(i+nx*(j-1));
    
%  end
%end


%  print out file for FEM computations

fid = fopen('realKernelFEM.dat','wt');
fprintf(fid,'%hd\n',real(KernelFEM));
fclose(fid);

fid = fopen('imagKernelFEM.dat','wt');
fprintf(fid,'%hd\n',imag(KernelFEM));
fclose(fid);

 % save vector d
        
	 fid = fopen('d1realFEM.dat','wt');
fprintf(fid,'%hd\n',real(drhs(:,1)));
fclose(fid);

 fid = fopen('d1imagFEM.dat','wt');
fprintf(fid,'%hd\n',imag(drhs(:,1)));
fclose(fid);

% save vector Sigma
        
	 fid = fopen('realSigmaFEM.dat','wt');
fprintf(fid,'%hd\n',real(Sigma(:,1)));
fclose(fid);

 fid = fopen('imagSigmaFEM.dat','wt');
fprintf(fid,'%hd\n',imag(Sigma(:,1)));
fclose(fid);


%fid = fopen('realKernelrowFEM.dat','wt');
%fprintf(fid,'%hd\n',real(KernelrowFEM));
%fclose(fid);

%fid = fopen('imagKernelrowFEM.dat','wt');
%fprintf(fid,'%hd\n',imag(KernelrowFEM));
%fclose(fid);


	  
